(ns opusdb.atomic.stm
  (:refer-clojure :exclude [ref deref ref-set alter dosync sync])
  (:require
   [opusdb.atomic.tx-hooks :as tx])
  (:import
   [java.util IdentityHashMap]
   [java.util.concurrent ConcurrentHashMap]
   [java.util.concurrent.atomic AtomicLong]
   [java.util.concurrent ThreadLocalRandom]))

(def ^:private max-history    16)
(def ^:private max-retries    256)
(def ^:private base-sleep-ms  1)
(def ^:private max-sleep-ms   32)
(def ^:private commit-lock    (Object.))

(def ^:private ^AtomicLong write-point      (AtomicLong.))
(def ^:private ^AtomicLong tx-counter       (AtomicLong.))
(def ^:private ^ConcurrentHashMap active-tx (ConcurrentHashMap.))

(def ^{:dynamic true} *tx* nil)
(def ^{:dynamic true} *trim-abort-hook* nil)

(defn- make-tx [retry-count]
  (let [id (.incrementAndGet tx-counter)
        tx {:id          id
            :read-point  (.get write-point)
            :read-set    (IdentityHashMap.)
            :write-set   (IdentityHashMap.)
            :retry-count retry-count
            :status      (volatile! ::active)}]
    (.put active-tx id tx)
    tx))

(defn- next-tx [current]
  (tx/rollback! (:id current))
  (.remove active-tx (:id current))
  (let [retries (:retry-count current)]
    (when (>= retries max-retries)
      (throw (ex-info "STM exceeded max retries" {:retries retries})))
    ;; Exponential backoff with ±25% jitter after 4 retries.
    (when (> retries 4)
      (let [base   (min max-sleep-ms (bit-shift-left base-sleep-ms (min (- retries 4) 6)))
            jitter (long (* base 0.25 (- (* 2 (.nextDouble (ThreadLocalRandom/current))) 1)))]
        (Thread/sleep (max 0 (long (+ base jitter))))))
    (make-tx (inc retries))))

(defn- abort []
  ;; Sentinel exception — caught by run-attempt to trigger a retry.
  (throw (ex-info "Transaction retry" {:type ::aborted})))

(defmacro with-max-history [n & body]
  `(binding [*max-history* ~n]
     ~@body))

(defn- check-active! [tx]
  ;; Bail early if wait-die has already marked us aborted.
  (when (= @(:status tx) ::aborted)
    (abort)))

(defn- find-entry [read-point history]
  ;; Newest-first scan; returns the latest entry visible at read-point.
  (loop [i (dec (count history))]
    (when (>= i 0)
      (let [entry (nth history i)]
        (if (<= (:write-point entry) read-point)
          entry
          (recur (dec i)))))))

(defn- trim-history [history]
  ;; Bound per-ref memory; dropping old versions only affects very long-lived readers.
  (if (> (count history) max-history)
    (vec (take-last max-history history))
    history))

(defn ref [initial-val]
  ;; Wraps value + version history + write-lock owner in a single atom.
  (let [wp    (.get write-point)
        entry {:value initial-val :write-point wp}]
    (atom {:value       initial-val
           :write-point wp
           :history     [entry]
           :owner       nil
           :lock        (Object.)})))

(defn- try-acquire! [target-ref tx]
  ;; Claims write ownership under the ref's own lock (not commit-lock).
  ;; Wait-die: younger tx (higher ID) preempts the owner; older tx yields.
  (let [claimer-id (:id tx)
        lock       (:lock @target-ref)]
    (monitor-enter lock)
    (try
      (let [owner-id (:owner @target-ref)]
        (cond
          (nil? owner-id)
          (do (swap! target-ref assoc :owner claimer-id) true)

          (= owner-id claimer-id)
          true

          ;; We're younger — preempt the owner and steal the ref.
          (> claimer-id owner-id)
          (do (when-some [owner-tx (.get active-tx owner-id)]
                (when (= @(:status owner-tx) ::active)
                  (vreset! (:status owner-tx) ::aborted)))
              (swap! target-ref assoc :owner claimer-id)
              true)

          :else false)) ; we're older — yield, let the younger owner finish
      (finally
        (monitor-exit lock)))))

(defn- validate-reads! [^IdentityHashMap read-set]
  ;; Called inside commit-lock; aborts if any read ref was written since our snapshot.
  (doseq [[r entry] read-set]
    (when (> (:write-point @r) (:write-point entry))
      (abort))))

(defn- apply-writes! [^IdentityHashMap write-set]
  ;; Advance write-point once, then stamp all writes with that commit-point.
  (let [commit-point (.incrementAndGet write-point)]
    (doseq [[r new-val] write-set]
      (swap! r (fn [{:keys [history] :as state}]
                 (assoc state
                        :value       new-val
                        :write-point commit-point
                        :owner       nil
                        :history     (trim-history
                                      (conj history
                                            {:value       new-val
                                             :write-point commit-point}))))))))

(defn- commit! [tx]
  (check-active! tx)
  (let [{:keys [id read-set write-set status]} tx]
    ;; Read-only txs skip the commit-lock entirely.
    (when (seq write-set)
      (locking commit-lock
        (check-active! tx)
        (validate-reads! read-set)
        (apply-writes! write-set)))
    (vreset! status ::committed)
    (.remove active-tx id)
    (tx/commit! id)))

(defn- run-attempt [tx body-fn]
  (try
    (binding [*tx* tx]
      (let [result (body-fn)]
        (commit! tx)
        [:ok result]))
    (catch clojure.lang.ExceptionInfo ex
      ;; ::aborted is ours — retry. All other ExceptionInfo propagates.
      (if (= (:type (ex-data ex)) ::aborted)
        [:abort nil]
        [:exception ex]))
    (catch Exception ex
      [:exception ex])))

(defn run-tx [body-fn]
  (loop [tx (make-tx 0)]
    (let [[tag value] (run-attempt tx body-fn)]
      (case tag
        :ok        value
        :abort     (recur (next-tx tx))
        :exception (do (tx/rollback! (:id tx))
                       (.remove active-tx (:id tx))
                       (throw value))))))

(defn sync [body-fn]
  ;; Already in a tx — participate directly; STM transactions are flat.
  (if *tx*
    (body-fn)
    (run-tx body-fn)))

(defmacro dosync [& body]
  `(sync (fn* [] ~@body)))

(defn deref [target-ref]
  (if-not *tx*
    (:value @(:hot target-ref))
    (let [tx                         *tx*
          ^IdentityHashMap write-set (:write-set tx)
          ^IdentityHashMap read-set  (:read-set tx)]
      (check-active! tx)
      (cond
        (.containsKey write-set target-ref)
        (.get write-set target-ref)

        (.containsKey read-set target-ref)
        (:value (.get read-set target-ref))

        :else
        (let [snapshot (find-entry (:read-point tx) (:cold target-ref))]
          (when-not snapshot
            (when *trim-abort-hook* (*trim-abort-hook*))
            (abort))
          (.put read-set target-ref snapshot)
          (:value snapshot))))))

(defn ref-set [target-ref new-val]
  (when-not *tx*
    (throw (IllegalStateException. "ref-set outside transaction")))
  (let [tx *tx*]
    (check-active! tx)
    ;; Acquire before buffering; yields if wait-die determines we're older.
    (when-not (try-acquire! target-ref tx)
      (abort))
    (.put ^IdentityHashMap (:write-set tx) target-ref new-val)
    new-val))

(defn alter [target-ref f & args]
  (ref-set target-ref (apply f (deref target-ref) args)))

(defn on-commit [handler]
  ;; Side-effect guaranteed to run once, after commit — safe for LongAdder etc.
  (if *tx*
    (tx/on-commit (:id *tx*) handler)
    (throw (IllegalStateException. "on-commit outside transaction"))))

(defn on-rollback [handler]
  ;; Cleanup hook run on abort or retry.
  (if *tx*
    (tx/on-rollback (:id *tx*) handler)
    (throw (IllegalStateException. "on-rollback outside transaction"))))